package com.example.pewjulie_inventorymanagementapp.adapter;

// Class for binding Items to the RecyclerView
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pewjulie_inventorymanagementapp.db.DBHelper;
import com.example.pewjulie_inventorymanagementapp.R;
import com.example.pewjulie_inventorymanagementapp.model.Item;

import java.util.ArrayList;

// Binds inventory data to the RecyclerView
public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    // List of inventory items
    ArrayList<Item> items;
    // Initializes data list
    public DataAdapter(ArrayList<Item>) {
    }

    public void updateList(ArrayList<Item> newItems){
        this.items = newItems;
        notifyDataSetChanged();
    }
    // Represents each item in the RecyclerView
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, quantity;
        Button deleteBtn, editBtn;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemName);
            quantity = itemView.findViewById(R.id.itemQty);
            deleteBtn = itemView.findViewById(R.id.deleteButton);
            editBtn = itemView.findViewById(R.id.editButton);
        }
    }

    // Used to bind data to each ViewHolder
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item item = dataList.get(position);
        holder.name.setText(item.getItemName());
        holder.quantity.setText(String.valueOf(item.getQuantity()));

        // Click listener for the delete button
        holder.deleteBtn.setOnClickListener(v -> {
            // Delete item and update the UI
            dbHelper.deleteItem(item.getId());
            dataList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, dataList.size());
        });

        // Click listener for the edit button
        holder.editBtn.setOnClickListener(v -> showEditDialog(item, position));
    }

    // Shows a diolog to allow the user to edit items
    private void showEditDialog(Item item, int position) {
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_edit_item, null);
        EditText nameEdit = dialogView.findViewById(R.id.editNameInput);
        EditText qtyEdit = dialogView.findViewById(R.id.editQtyInput);

        // Set current values in the diolog inputs
        nameEdit.setText(item.getItemName());
        qtyEdit.setText(String.valueOf(item.getQuantity()));

        // Show the AlertDialog for edits
        new AlertDialog.Builder(context)
                .setTitle("Edit item")
                .setView(dialogView)
                .setPositiveButton("Update", (dialog, which) -> {
                    // Get updated input values
                    String newName = nameEdit.getText().toString().trim();
                    int newQty = Integer.parseInt(qtyEdit.getText().toString().trim());

                    // Update the item in database
                    item.setItemName(newName);
                    item.setQuantity(newQty);
                    dbHelper.updateItem(item.getId(), newName, newQty);
                    notifyItemChanged(position); // Refresh
                })
                .setNegativeButton("Cancel", null) // Dismiss
                .show();
    }

    // Return total number of items in the list
    @Override
    public int getItemCount() {
        return dataList.size();
    }
}