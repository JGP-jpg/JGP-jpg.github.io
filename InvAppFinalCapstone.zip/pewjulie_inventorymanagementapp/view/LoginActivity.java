package com.example.pewjulie_inventorymanagementapp.view;

// This class is going to be the Login screen

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.pewjulie_inventorymanagementapp.R;
import com.example.pewjulie_inventorymanagementapp.SmsPermissionActivity;
import com.example.pewjulie_inventorymanagementapp.model.User;
import com.example.pewjulie_inventorymanagementapp.viewmodel.LoginViewModel;

// Handles the user login and automatic registration if the user does not exist
public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private Button loginButton;

    // Login logic handled by ViewModel
    private LoginViewModel loginViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Load Login UI layout
        setContentView(R.layout.activity_main);

        // Bind the UI elements to the layout
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_btn);

        // Initialize ViewModel
        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);

        // Observe LiveData list of users and update cache
        loginViewModel.getAllUsers().observe(this, users -> {
            loginViewModel.setCredentialsMap(users); // Cache them in ViewModel
        });

        // Handle login button click
        loginButton.setOnClickListener(view -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate proper form
            if (username.isEmpty() || password.isEmpty()) {

                Toast.makeText(this, "Please enter both fields.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate the login
            if (loginViewModel.isValidLogin(username, password)) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, SmsPermissionActivity.class));
                finish();
            }
            // If the user does not exist, create an account
            else if (!loginViewModel.isEmailTaken(username)) {
                loginViewModel.insertUser(new User(username, password));
                Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, SmsPermissionActivity.class));
                finish();
            }
            // If the user does exist but the password is incorrect
            else {
                Toast.makeText(this, "Incorrect password.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}