package com.example.pewjulie_inventorymanagementapp.repository;

public class InventoryRepository {
    // private DBHelper dbHelper;
    // private MutableLiveData = new MutableLiveData

    // public InventoryRepository(Context context){
    // dbHelper = new DBHelper(context)
    // loadItemsFromDb()}

    // private loadItemsFromDb()

    // public LiveData getItems()

    // public addItems()

    // public deleteItems()

    // public updateItems()
}
