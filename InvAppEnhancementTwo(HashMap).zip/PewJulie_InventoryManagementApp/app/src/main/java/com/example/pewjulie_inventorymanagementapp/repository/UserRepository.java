package com.example.pewjulie_inventorymanagementapp.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.pewjulie_inventorymanagementapp.db.Database;
import com.example.pewjulie_inventorymanagementapp.db.UserDao;
import com.example.pewjulie_inventorymanagementapp.model.User;

import java.util.List;

public class UserRepository {

    private final UserDao userDao;

    public UserRepository(Application application){
        // Initialize DAO and get database instance
        Database db = Database.getDatabase(application);
        userDao = db.userDao();
    }

    // Return LiveData of all users
    public LiveData<List<User>> getAllUsers() {
        return userDao.getAllUsers();
    }

    // Insert a user in the background
    public void insertUser(User user) {
        Database.databaseWriteExecutor.execute(() -> {
            userDao.insert(user);
        });
    }
}
