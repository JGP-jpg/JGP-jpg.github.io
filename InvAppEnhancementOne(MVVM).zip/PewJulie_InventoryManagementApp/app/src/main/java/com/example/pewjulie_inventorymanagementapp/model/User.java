package com.example.pewjulie_inventorymanagementapp.model;

// This class is the User login model
public class User {
}
