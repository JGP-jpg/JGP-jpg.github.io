package com.example.pewjulie_inventorymanagementapp.view;

// This class will be for users to create an account if one does not already exist
public class RegisterActivity {
}
