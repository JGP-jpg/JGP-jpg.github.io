package com.example.pewjulie_inventorymanagementapp.view;

// This class is going to be the Inventory screen
// Many current errors due to temporary pseudocode within other classes and incomplete code

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pewjulie_inventorymanagementapp.R;
import com.example.pewjulie_inventorymanagementapp.viewmodel.InventoryViewModel;
import com.example.pewjulie_inventorymanagementapp.model.Item;
import com.example.pewjulie_inventorymanagementapp.adapter.DataAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DataActivity extends AppCompatActivity {
    // ViewModel that manages inventory data
    private InventoryViewModel inventoryViewModel;
    // Adapter that handles the display of inventory items
    private DataAdapter dataAdapter;

    // Keep track of item being edited
    private Item itemBeingEdited = null;

    // UI references
    private EditText inputItemName;
    private EditText inputQuantity;
    private FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // The layout for this screen
        setContentView(R.layout.activity_data_display);

        // Initialize UI references
        inputItemName = findViewById(R.id.inputItemName);
        inputQuantity = findViewById(R.id.inputQuantity);
        fab = findViewById(R.id.add_item_fab);

        // Reference to RecyclerView in the layout
        RecyclerView recyclerView = findViewById(R.id.dataRecyclerView);
        // Initialize the adapter and attach it to the RecyclerView
        dataAdapter = new DataAdapter();
        recyclerView.setAdapter(dataAdapter);
        // Set layout manager to control how items are displayed
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set up item action listener for edit and delete
        dataAdapter.setOnItemActionListener(new DataAdapter.OnItemActionListener() {
            @Override
            public void onEdit(Item item) {
                populateFieldsForEdit(item); // Populate input fields with edited item

            }

            @Override
            public void onDelete(Item item) {
                inventoryViewModel.delete(item);
            }
        });

        // Create or retrieve existing ViewModel associated with this Activity
        inventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);

        // Observe the LiveData list of items
        inventoryViewModel.getAllItems().observe(this, items -> {
            dataAdapter.submitList(items); // Updates the RecyclerView
        });

        // Handle Floating Action Button click to add a new item
        fab.setOnClickListener(v -> {
            String name = inputItemName.getText().toString().trim();
            String qtyText = inputQuantity.getText().toString().trim();

            if (name.isEmpty() || qtyText.isEmpty()) {
                Toast.makeText(this, "Please enter name and quantity.", Toast.LENGTH_SHORT).show();
                return;
            }
            int qty;
            try {
                qty = Integer.parseInt(qtyText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (itemBeingEdited != null) {
                // Updating existing item
                itemBeingEdited.setName(name);
                itemBeingEdited.setQuantity(qty);
                inventoryViewModel.update(itemBeingEdited);

                // Reset editing state
                itemBeingEdited = null;
            } else {
                // Adding new item
                inventoryViewModel.insert(new Item(name, qty));
            }

            // Clear input fields after operation
            inputItemName.setText("");
            inputQuantity.setText("");
        });

    }

    // Populates fields with selected item's data so that the item can be edited
    private void populateFieldsForEdit(Item item) {
        inputItemName.setText(item.getName());
        inputQuantity.setText(String.valueOf((item.getQuantity())));

        // Keep reference to the item being edited
        itemBeingEdited = item;
    }

}