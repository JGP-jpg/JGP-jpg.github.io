package com.example.pewjulie_inventorymanagementapp.db;

// This is the Room DAO for Inventory (another future enhancement)
public interface ItemDao {
}
