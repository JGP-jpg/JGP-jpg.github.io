package com.example.pewjulie_inventorymanagementapp.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Model class to represent each inventory item
@Entity(tableName = "items")
public class Item {
    @PrimaryKey(autoGenerate = true)
    // Unique ID
    private int id;

    // Name of the item
    private String name;
    // Quantity of the item
    private int quantity;

    // Getters and Setters
    public Item(int id, String name, int quantity){
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }
}