package com.example.pewjulie_inventorymanagementapp.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.pewjulie_inventorymanagementapp.model.User;

import java.util.List;

// This is the Room DAO for Login (another future enhancement)
@Dao
public interface UserDao {
    // Query to get all users from users table
    @Query("SELECT * FROM users")
    LiveData<List<User>> getAllUsers();

    // Insert a new user, but ignore it if they already exist
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(User user);
}
