package com.example.pewjulie_inventorymanagementapp.db;

// This is the Room database (will be used in future enhancement)

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.pewjulie_inventorymanagementapp.model.Item;
import com.example.pewjulie_inventorymanagementapp.model.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Annotate database with entities and version
@androidx.room.Database(entities = {User.class, Item.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // Dao getters
    public abstract UserDao userDao();
    public abstract ItemDao itemDao();

    // Singleton instance
    private static volatile AppDatabase INSTANCE;

    // Background thread executor
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(4);

    // Singleton access method
    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "inventory_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
