package com.example.pewjulie_inventorymanagementapp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.pewjulie_inventorymanagementapp.model.Item;
import com.example.pewjulie_inventorymanagementapp.repository.InventoryRepository;

import java.util.List;

public class InventoryViewModel extends AndroidViewModel {

    // Repository that handles data operations
    private InventoryRepository repository;
    // LiveData list of all inventory items observed by UI
    private LiveData<List<Item>> allItems;

    // Constructor
    public InventoryViewModel(@NonNull Application application) {
        super(application);
        // Initialize the repository with the application context
        repository = new InventoryRepository(application);
        // Get the LiveData list of all items from the repository
        allItems = repository.getAllItems();
    }

    // Expose LiveData to UI so it can observe changes
    public LiveData<List<Item>> getAllItems() {
        return allItems;
    }

    // Call repository to insert a new item in the database
    public void insert(Item item){
        repository.insert(item);
    }

    public void update(Item item) {
        repository.update(item);
    }

    // Call repository to delete an item from the database
    public void delete(Item item){
        repository.delete(item);
    }
}
