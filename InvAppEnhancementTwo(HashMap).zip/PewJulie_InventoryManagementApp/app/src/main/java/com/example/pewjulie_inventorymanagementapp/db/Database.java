package com.example.pewjulie_inventorymanagementapp.db;

// This is the Room database (will be used in future enhancement)

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.pewjulie_inventorymanagementapp.model.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@androidx.room.Database(entities = {User.class}, version = 1, exportSchema = false)
public abstract class Database extends RoomDatabase {

    public abstract UserDao userDao();

    // Singleton instance
    private static volatile Database INSTANCE;

    // Background thread executor
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(4);

    public static Database getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (Database.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            Database.class, "inventory_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
