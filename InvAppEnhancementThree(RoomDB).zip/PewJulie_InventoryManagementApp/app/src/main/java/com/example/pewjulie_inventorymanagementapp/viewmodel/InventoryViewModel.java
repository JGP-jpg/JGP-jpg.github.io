package com.example.pewjulie_inventorymanagementapp.viewmodel;

import androidx.lifecycle.AndroidViewModel;

// Temporary placeholder pseudocode to meet MVVM enhancement
public class InventoryViewModel extends AndroidViewModel {
    // private InventoryRepository
    // private LiveData

    // public InventoryViewModel(@NonNull Application) {
    // super
    // repository = new
    // items = .getItems()

    //public LiveData getItems()


    // public addItem

    // public deleteItem

    // public updateItem
}
