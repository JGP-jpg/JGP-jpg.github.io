package com.example.pewjulie_inventorymanagementapp.repository;

public class UserRepository {
}
