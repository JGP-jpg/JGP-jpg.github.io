package com.example.pewjulie_inventorymanagementapp.db;

// This is the Room database (will be used in future enhancement)
public class Database {
}
