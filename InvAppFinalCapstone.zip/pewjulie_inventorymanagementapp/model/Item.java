package com.example.pewjulie_inventorymanagementapp.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

// Model class to represent each inventory item
@Entity(tableName = "items")
public class Item {
    @PrimaryKey(autoGenerate = true)
    // Unique ID
    private int id;

    // Name of the item
    @ColumnInfo(name = "name")
    private String name;
    // Quantity of the item
    @ColumnInfo(name = "quantity")
    private int quantity;

    // Getters and Setters
    public Item(String name, int quantity){ // This constructor is used by Room
        this.name = name;
        this.quantity = quantity;
    }

    @Ignore
    public Item(){

    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}