package com.example.pewjulie_inventorymanagementapp.db;

// This class is the SQLite helper (will later use Room in the future enhancement)
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

// Handles database creation and CRUD
public class DBHelper extends SQLiteOpenHelper {
    // Initializes the database using the name Login.db
    public DBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }

    // Used when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Table for users
        db.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password TEXT)");
        // Table for inventory items
        db.execSQL("CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, quantity INTEGER)");
    }

    // Used when the database requires an upgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drops the tables to then recreate the tables
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");
        onCreate(db);
    }

    // Inserts new user into the table
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long result = db.insert("users", null, values);
        return result != -1;
    }

    // Checks if the user already exists
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username=? AND password=?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Checks if a username already exists during registration
    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username=?",
                new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Inserts a new item into the table
    public boolean insertItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("quantity", quantity);
        long result = db.insert("inventory", null, values);
        return result != -1;
    }

    // Update an existing item already in the table
    public boolean updateItem(int id, String newName, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", newName);
        values.put("quantity", newQuantity);
        int result = db.update("inventory", values, "id=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Delete an item from the table
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("inventory", "id=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Returns a Cursor containing all of the inventory items
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM inventory", null);
    }
}
