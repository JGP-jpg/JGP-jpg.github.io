package com.example.pewjulie_inventorymanagementapp.view;

// This class is going to be the Login screen

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pewjulie_inventorymanagementapp.db.DBHelper;
import com.example.pewjulie_inventorymanagementapp.R;
import com.example.pewjulie_inventorymanagementapp.SmsPermissionActivity;

// Handles the user login and automatic registration if the user does not exist
public class LoginActivity extends AppCompatActivity {
    // Declare UI elements and DB helper
    EditText username, password;
    Button loginButton;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        // This loads the UI layout
        setContentView(R.layout.activity_main);

        // Bind UI elements to layout components
        username = findViewById(R.id.username_input);
        password = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_btn);
        // Create database helper instance
        dbHelper = new DBHelper(this);

        // Click listen on the login button
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
               String user = username.getText().toString().trim();
               String pass = password.getText().toString().trim();

               // Verify that both fields are filled
               if (user.isEmpty() || pass.isEmpty()) {
                   Toast.makeText(LoginActivity.this, "Please enter both fields.", Toast.LENGTH_SHORT).show();
                   return;
               }

               // Check for existing credentials of the user and send user to next page
               if (dbHelper.checkUser(user, pass)) {
                   Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                   startActivity(new Intent(LoginActivity.this, SmsPermissionActivity.class));
                   finish();
               }
               // If the username does not exist, create a new account and send user to next page
               else if (!dbHelper.checkUsernameExists(user)){
                   boolean inserted = dbHelper.insertUser(user, pass);
                   if (inserted) {
                       Toast.makeText(LoginActivity.this, "Account created, login successful!", Toast.LENGTH_SHORT).show();
                       startActivity(new Intent(LoginActivity.this, SmsPermissionActivity.class));
                       finish();
                   } else {
                       Toast.makeText(LoginActivity.this, "Error creating account.", Toast.LENGTH_SHORT).show();
                   }
                }
               // If the username exists but the password is incorrect
               else {
                   Toast.makeText(LoginActivity.this, "Incorrect password.", Toast.LENGTH_SHORT).show();
               }
            }
        });
    }
}