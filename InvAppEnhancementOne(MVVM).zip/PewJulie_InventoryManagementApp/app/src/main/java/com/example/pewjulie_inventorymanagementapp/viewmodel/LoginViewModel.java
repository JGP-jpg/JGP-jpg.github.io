package com.example.pewjulie_inventorymanagementapp.viewmodel;

public class LoginViewModel {
}
