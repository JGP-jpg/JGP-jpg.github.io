package com.example.pewjulie_inventorymanagementapp.db;

// This is the Room DAO for Login (another future enhancement)
public interface UserDao {
}
