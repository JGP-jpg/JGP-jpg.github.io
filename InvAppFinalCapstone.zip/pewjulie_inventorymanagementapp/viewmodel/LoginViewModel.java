package com.example.pewjulie_inventorymanagementapp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.pewjulie_inventorymanagementapp.model.User;
import com.example.pewjulie_inventorymanagementapp.repository.UserRepository;

import java.util.HashMap;
import java.util.List;

public class LoginViewModel extends AndroidViewModel {

    private final UserRepository userRepository;

    // LiveData to observe users from Room
    private final LiveData<List<User>> allUsers;

    // Cache of user email and password pairs for faster validation
    private final HashMap<String, String> credentialsMap = new HashMap<>();

    public LoginViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
        allUsers = userRepository.getAllUsers();
    }

    // Exposes users LiveData to be observed in the UI layer
    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    // Populate credentials map for fast lookup
    public void setCredentialsMap(List<User> users) {
        credentialsMap.clear();
        for (User user: users) {
            credentialsMap.put(user.getUsername(), user.getPassword());
        }
    }

    // Check if the email exists and password matches. Valid if so
    public boolean isValidLogin(String email, String password) {
        return credentialsMap.containsKey(email) &&
                password.equals(credentialsMap.get(email));
    }

    // Check if the email is taken
    public boolean isEmailTaken(String email) {
        return credentialsMap.containsKey(email);
    }

    // Insert a new user; repository
    public void insertUser(User user) {
        userRepository.insertUser(user);
    }
}
