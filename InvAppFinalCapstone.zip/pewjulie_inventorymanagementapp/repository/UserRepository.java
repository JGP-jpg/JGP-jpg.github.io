package com.example.pewjulie_inventorymanagementapp.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.pewjulie_inventorymanagementapp.db.AppDatabase;
import com.example.pewjulie_inventorymanagementapp.db.UserDao;
import com.example.pewjulie_inventorymanagementapp.model.User;

import java.util.List;

// Repository class to handle operations related to Users
public class UserRepository {

    private final UserDao userDao;

    public UserRepository(Application application){
        // Initialize DAO and get database instance
        AppDatabase db = AppDatabase.getDatabase(application);
        userDao = db.userDao();
    }

    // Return LiveData of all users
    public LiveData<List<User>> getAllUsers() {
        return userDao.getAllUsers();
    }

    // Insert a user in the background
    public void insertUser(User user) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            userDao.insert(user);
        });
    }

    // Get a user for login
    public User getUser(String username, String password) {
        return userDao.getUser(username, password); // Call from background thread
    }
}
