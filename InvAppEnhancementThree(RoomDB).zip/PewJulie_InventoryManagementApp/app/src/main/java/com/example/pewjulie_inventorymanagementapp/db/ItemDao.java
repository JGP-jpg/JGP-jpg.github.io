package com.example.pewjulie_inventorymanagementapp.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.pewjulie_inventorymanagementapp.model.Item;

import java.util.List;

// This is the Room DAO for Inventory
@Dao
public interface ItemDao {
    // Insert an item into the database
    @Insert
    void insertItem(Item item);

    // Get all items
    @Query("SELECT * FROM items")
    LiveData<List<Item>> getAllItems();

    // Delete an item from the database
    @Delete
    void deleteItem(Item item);
}
