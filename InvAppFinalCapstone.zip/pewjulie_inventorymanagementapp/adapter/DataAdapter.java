package com.example.pewjulie_inventorymanagementapp.adapter;

// Class for binding Items to the RecyclerView (STILL IN PROGRESS- INCOMPLETE CODE)

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pewjulie_inventorymanagementapp.R;
import com.example.pewjulie_inventorymanagementapp.model.Item;

// Uses ListAdapter and DiffUtil for automatic updates when data is changed
public class DataAdapter extends ListAdapter<Item, DataAdapter.ItemViewHolder> {

    public interface OnItemActionListener {
        void onEdit(Item item);
        void onDelete(Item item);
    }

    private OnItemActionListener actionListener;

    public void setOnItemActionListener(OnItemActionListener listener) {
        this.actionListener = listener;
    }
    // Constructor
   public DataAdapter() {
       super(DIFF_CALLBACK);
   }

   // DiffUtil callback to optimize RecyclerView updates
   private static final DiffUtil.ItemCallback<Item> DIFF_CALLBACK =
           new DiffUtil.ItemCallback<Item>() {
               // Check if two items represent the same database entry
               @Override
               public boolean areItemsTheSame(Item oldItem, Item newItem) {
                   return oldItem.getId() == newItem.getId();
               }

               // Check if contents of two items are the same
               @Override
               public boolean areContentsTheSame(Item oldItem, Item newItem) {
                   return oldItem.getName().equals(newItem.getName()) &&
                           oldItem.getQuantity() == newItem.getQuantity();
               }
           };

   // Called by RecyclerView to create new ViewHolder
   @NonNull
   @Override
   public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       // Inflate the XML layout for a single item row
       View itemView = LayoutInflater.from(parent.getContext())
               .inflate(R.layout.item_data_row, parent, false);
       return new ItemViewHolder(itemView);
   }

   // Called by RecyclerView to bind data to a ViewHolder
   @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
       // Get the current Item from the ListAdapter
       Item current = getItem(position);
       // Bind the item name and quantity to the corresponding TextViews
       holder.nameText.setText(current.getName());
       holder.qtyText.setText(String.valueOf(current.getQuantity()));

       holder.btnEdit.setOnClickListener(v -> {
           if (actionListener != null) {
               actionListener.onEdit(current);
           }
       });

       holder.btnDelete.setOnClickListener(v -> {
           if (actionListener != null) {
               actionListener.onDelete(current);
           }
       });
   }

   // ViewHolder class holds references to views for each data item
   class ItemViewHolder extends RecyclerView.ViewHolder {
       // To display item name and quantity
       private final TextView nameText, qtyText;
       Button btnEdit, btnDelete;

       public ItemViewHolder(@NonNull View itemView) {
           super(itemView);
           // Initialize the TextViews using the item view layout ID
           nameText = itemView.findViewById(R.id.item_name_text);
           qtyText = itemView.findViewById(R.id.item_qty_text);
           btnEdit = itemView.findViewById(R.id.btn_edit);
           btnDelete = itemView.findViewById(R.id.btn_delete);
       }
   }
}