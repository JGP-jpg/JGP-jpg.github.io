package com.example.pewjulie_inventorymanagementapp;

// This class will likely be removed entirely
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.pewjulie_inventorymanagementapp.view.DataActivity;

// Checks for and requests permission before moving to next page
public class SmsPermissionActivity extends AppCompatActivity {
    // A constant code to identify permission request
    private static final int SMS_PERMISSION_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // If not, request permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            // If permission is already granted, move to inventory screen
            proceedToInventory();
        }
    }

    // Moves to the inventory screen
    private void proceedToInventory() {
        Intent intent = new Intent(SmsPermissionActivity.this, DataActivity.class);
        startActivity(intent);
        finish(); // Close the permission screen
    }

    // Callback for user's response to the request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                          @NonNull String[] permissions,
                                          @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Check if user response matches request code
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                // If permission is denied, show message and proceed
                Toast.makeText(this, "SMS permission denied. Proceeding.", Toast.LENGTH_SHORT).show();
            }
            // No matter what, proceed to inventory screen
            proceedToInventory();
        }
    }
}
