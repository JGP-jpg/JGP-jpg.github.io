package com.example.pewjulie_inventorymanagementapp.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.pewjulie_inventorymanagementapp.db.AppDatabase;
import com.example.pewjulie_inventorymanagementapp.db.ItemDao;
import com.example.pewjulie_inventorymanagementapp.model.Item;

import java.util.List;

// Repository to handle operations related to Items
public class InventoryRepository {
    private ItemDao itemDao;
    private LiveData<List<Item>> allItems;

    public InventoryRepository(Application application){
        // Get the ItemDao from the AppDatabase
        AppDatabase db = AppDatabase.getDatabase(application);
        itemDao = db.itemDao();
        allItems = itemDao.getAllItems();
    }

    // Return all items as LiveData
    public LiveData<List<Item>> getAllItems() {
        return allItems;
    }

    // Insert an item on background thread
    public void insert(Item item) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            itemDao.insertItem(item);
        });
    }

    // Delete an item on background thread
    public void delete(Item item) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            itemDao.deleteItem(item);
        });
    }
}
