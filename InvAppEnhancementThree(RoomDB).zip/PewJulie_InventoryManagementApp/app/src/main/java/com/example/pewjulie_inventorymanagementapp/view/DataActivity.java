package com.example.pewjulie_inventorymanagementapp.view;

// This class is going to be the Inventory screen
// Many current errors due to temporary pseudocode within other classes and incomplete code

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pewjulie_inventorymanagementapp.db.DBHelper;
import com.example.pewjulie_inventorymanagementapp.R;
import com.example.pewjulie_inventorymanagementapp.adapter.DataAdapter;
import com.example.pewjulie_inventorymanagementapp.model.Item;
import com.example.pewjulie_inventorymanagementapp.viewmodel.InventoryViewModel;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {
    // UI elements for the item name input and quantity input
    private InventoryViewModel viewModel;
    private RecyclerView recyclerView;
    private DataAdapter adapter;
    private FloatingActionButton addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initializes RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        adapter = new DataAdapter(new ArrayList<>());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        addButton = findViewById(R.id.addButton);

        // Initializes ViewModel
        viewModel = new ViewModelProvider(this).get(InventoryViewModel.class);

        // Observe Livedata from ViewModel
         viewModel.getItems().observe(this, items -> {
            adapter.updateList(items);
         });

         // Add button click
        addButton.setOnClickListener(v -> {
             // Dummy item
            Item newItem = new Item(0, "New Item", 1);
            viewModel.addItem(newItem);
         });
    }

}